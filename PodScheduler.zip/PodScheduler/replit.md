# Overview

This is an interactive Sikh culture quiz game built with React, TypeScript, and Express. The application features a progressive level system where players answer questions about Sikh history, teachings, and culture. Players unlock new levels by completing previous ones, with celebrations and scoring systems to enhance engagement. The game includes audio effects, smooth animations, and a modern UI built with Radix UI components and Tailwind CSS.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with custom theming and Radix UI components for accessible UI elements
- **State Management**: Zustand with persist middleware for game state, quiz progress, and audio controls
- **Animations**: Framer Motion for smooth transitions, celebrations, and interactive feedback
- **Audio**: HTML5 Audio API integration with custom hooks for background music and sound effects

## Backend Architecture  
- **Server**: Express.js with TypeScript running on Node.js
- **API Design**: RESTful API structure with `/api` prefix (currently minimal implementation)
- **Development**: Hot module replacement with Vite middleware integration
- **Error Handling**: Centralized error middleware with status code and message handling
- **Logging**: Custom request/response logging with timing information

## Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema**: User management with username/password fields (prepared for future authentication)
- **Development Storage**: In-memory storage implementation for rapid prototyping
- **Persistence**: Browser localStorage for game progress, level completion, and user preferences
- **Migrations**: Drizzle Kit for database schema migrations and version control

## Game Logic & State Management
- **Quiz System**: Progressive level unlocking with score tracking and completion states
- **Game Phases**: Level selection, question answering, level completion, and game completion flows
- **Progress Tracking**: Persistent storage of unlocked levels, scores, and completion status
- **Audio Management**: Centralized audio state with mute/unmute functionality and sound effect triggering

## External Dependencies

- **Database**: Neon PostgreSQL serverless database via `@neondatabase/serverless`
- **UI Components**: Radix UI primitive components for accessibility and consistency
- **Fonts**: Inter font family via Fontsource for consistent typography
- **Development Tools**: 
  - ESBuild for production bundling
  - TSX for development server execution
  - PostCSS with Autoprefixer for CSS processing
- **Animation**: Framer Motion for complex animations and transitions
- **State Persistence**: Zustand persist middleware for client-side data retention
- **Type Safety**: Zod for runtime type validation with Drizzle schema integration